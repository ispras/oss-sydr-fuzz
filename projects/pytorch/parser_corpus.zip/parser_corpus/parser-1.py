class FooTest:
  def __init__(self, x):
    self.x = x

  def get_x(self):
    return self.x

  an_attribute : Tensor